// Gotten from https://paystack.com/docs/payments/verify-payments/


const https = require('https')


const options = {
  hostname: 'api.paystack.co',
  port: 443,
  path: '/transaction/verify/T222584780787242', 
  // Used a reference of one of my test payments
  method: 'GET',
  headers: {
    Authorization: 'sk_test_1b0140f12e42fe87c0be2ce1b07662b69bdb8816'
  }
}

https.request(options, res => {
  let data = ''
  resp.on('data', (chunk) => {
    data += chunk
  });
  resp.on('end', () => {
    console.log(JSON.parse(data))
  })
}).on('error', error => {
  console.error(error)
})
